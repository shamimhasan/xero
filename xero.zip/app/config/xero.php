<?php

return array(
    'key' => 'XUYL6CQWNL0DLKRWLCOTQXRVWFWAFR',
    'secret' => '7LPXQVF2ES6ABMDTISTOSAQVNN3VD3',
    'publicPath' => app_path() . '/config/xero/publickey.cer',
    'privatePath' => app_path() . '/config/xero/privatekey.pem',
    'format' => 'application/json'
);
