<?php

class Transaction extends Eloquent {

    protected $table = 'transactions';
    
}